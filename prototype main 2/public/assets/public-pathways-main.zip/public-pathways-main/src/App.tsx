import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navigation from "./components/Navigation";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";

// Citizen App Pages
import Citizen from "./pages/Citizen";
import CitizenLogin from "./pages/citizen/Login";
import CitizenSignup from "./pages/citizen/Signup";
import CitizenHome from "./pages/citizen/Home";
import CitizenChatbot from "./pages/citizen/Chatbot";
import CitizenReport from "./pages/citizen/Report";
import CitizenReports from "./pages/citizen/Reports";
import CitizenReportDetail from "./pages/citizen/ReportDetail";
import CitizenNearby from "./pages/citizen/Nearby";
import CitizenProfile from "./pages/citizen/Profile";

// Admin Dashboard Pages
import Admin from "./pages/Admin";
import AdminLogin from "./pages/admin/Login";
import AdminSignup from "./pages/admin/Signup";
import AdminMap from "./pages/admin/Map";
import AdminComplaints from "./pages/admin/Complaints";
import AdminComplaintDetail from "./pages/admin/ComplaintDetail";
import AdminAssign from "./pages/admin/Assign";
import AdminAnalytics from "./pages/admin/Analytics";
import AdminWorkers from "./pages/admin/Workers";

// NGO Portal Pages
import NGO from "./pages/NGO";
import NGOLogin from "./pages/ngo/Login";
import NGOSignup from "./pages/ngo/Signup";
import NGOTasks from "./pages/ngo/Tasks";
import NGOUpdate from "./pages/ngo/Update";
import NGOMetrics from "./pages/ngo/Metrics";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Navigation />
        <Routes>
          <Route path="/" element={<Index />} />
          
          {/* Citizen Routes */}
          <Route path="/citizen" element={<Citizen />} />
          <Route path="/citizen/login" element={<CitizenLogin />} />
          <Route path="/citizen/signup" element={<CitizenSignup />} />
          <Route path="/citizen/home" element={<CitizenHome />} />
          <Route path="/citizen/chatbot" element={<CitizenChatbot />} />
          <Route path="/citizen/report" element={<CitizenReport />} />
          <Route path="/citizen/reports" element={<CitizenReports />} />
          <Route path="/citizen/report/:id" element={<CitizenReportDetail />} />
          <Route path="/citizen/nearby" element={<CitizenNearby />} />
          <Route path="/citizen/profile" element={<CitizenProfile />} />

          {/* Admin Routes */}
          <Route path="/admin" element={<Admin />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin/signup" element={<AdminSignup />} />
          <Route path="/admin/map" element={<AdminMap />} />
          <Route path="/admin/complaints" element={<AdminComplaints />} />
          <Route path="/admin/complaint/:id" element={<AdminComplaintDetail />} />
          <Route path="/admin/assign" element={<AdminAssign />} />
          <Route path="/admin/analytics" element={<AdminAnalytics />} />
          <Route path="/admin/workers" element={<AdminWorkers />} />

          {/* NGO Routes */}
          <Route path="/ngo" element={<NGO />} />
          <Route path="/ngo/login" element={<NGOLogin />} />
          <Route path="/ngo/signup" element={<NGOSignup />} />
          <Route path="/ngo/tasks" element={<NGOTasks />} />
          <Route path="/ngo/update" element={<NGOUpdate />} />
          <Route path="/ngo/metrics" element={<NGOMetrics />} />

          {/* Catch-all route */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
