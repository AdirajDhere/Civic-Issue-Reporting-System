// Mock data for SheharSaaf platform

export interface Issue {
  id: string;
  title: string;
  description: string;
  category: 'roads' | 'water' | 'waste' | 'electricity' | 'health' | 'other';
  priority: 'low' | 'medium' | 'high' | 'critical';
  status: 'pending' | 'acknowledged' | 'in-progress' | 'resolved' | 'closed';
  location: {
    address: string;
    coordinates: { lat: number; lng: number };
  };
  reportedBy: {
    name: string;
    phone: string;
    id: string;
  };
  assignedTo?: {
    name: string;
    type: 'municipal' | 'ngo';
    id: string;
  };
  images: string[];
  upvotes: number;
  comments: Comment[];
  createdAt: string;
  updatedAt: string;
  aiSeverity: 'low' | 'medium' | 'high' | 'critical';
  estimatedResolution: string;
}

export interface Comment {
  id: string;
  author: string;
  message: string;
  timestamp: string;
  type: 'citizen' | 'admin' | 'ngo';
}

export interface Worker {
  id: string;
  name: string;
  type: 'municipal' | 'ngo';
  contact: string;
  location: { lat: number; lng: number };
  assignedIssues: number;
  completedIssues: number;
  rating: number;
  specialization: string[];
}

// Mock Issues Data
export const mockIssues: Issue[] = [
  {
    id: "SHR001",
    title: "Broken Street Light on MG Road | एमजी रोड पर टूटी स्ट्रीट लाइट",
    description: "Street light has been non-functional for 3 days, causing safety concerns for pedestrians and vehicles.",
    category: "electricity",
    priority: "high",
    status: "in-progress",
    location: {
      address: "MG Road, Sector 14, New Delhi",
      coordinates: { lat: 28.5355, lng: 77.3910 }
    },
    reportedBy: {
      name: "Rahul Sharma",
      phone: "+91 98765 43210",
      id: "USR001"
    },
    assignedTo: {
      name: "Delhi Municipal Corporation - Zone 1",
      type: "municipal",
      id: "MUN001"
    },
    images: ["/api/placeholder/400/300"],
    upvotes: 23,
    comments: [
      {
        id: "C001",
        author: "Admin",
        message: "Issue has been assigned to electrical team. Work to start within 24 hours.",
        timestamp: "2024-01-15T10:30:00Z",
        type: "admin"
      }
    ],
    createdAt: "2024-01-15T08:00:00Z",
    updatedAt: "2024-01-15T10:30:00Z",
    aiSeverity: "high",
    estimatedResolution: "24-48 hours"
  },
  {
    id: "SHR002", 
    title: "Pothole Near School Zone | स्कूल के पास गड्ढा",
    description: "Large pothole causing traffic congestion and potential accidents near children's school.",
    category: "roads",
    priority: "critical",
    status: "acknowledged",
    location: {
      address: "School Road, Vasant Vihar, New Delhi",
      coordinates: { lat: 28.5672, lng: 77.1567 }
    },
    reportedBy: {
      name: "Priya Singh",
      phone: "+91 87654 32109",
      id: "USR002"
    },
    assignedTo: {
      name: "Road Safety NGO",
      type: "ngo", 
      id: "NGO001"
    },
    images: ["/api/placeholder/400/300"],
    upvotes: 45,
    comments: [
      {
        id: "C002",
        author: "Municipal Officer",
        message: "Priority issue logged. Road repair crew will be dispatched tomorrow morning.",
        timestamp: "2024-01-14T15:45:00Z",
        type: "admin"
      }
    ],
    createdAt: "2024-01-14T09:15:00Z",
    updatedAt: "2024-01-14T15:45:00Z",
    aiSeverity: "critical",
    estimatedResolution: "48-72 hours"
  },
  {
    id: "SHR003",
    title: "Water Leakage in Residential Area | आवासीय क्षेत्र में पानी का रिसाव",
    description: "Continuous water leakage from main pipeline causing waterlogging and wastage.",
    category: "water",
    priority: "medium",
    status: "resolved",
    location: {
      address: "Block C, Dwarka, New Delhi",
      coordinates: { lat: 28.5921, lng: 77.0460 }
    },
    reportedBy: {
      name: "Amit Kumar",
      phone: "+91 76543 21098",
      id: "USR003"
    },
    assignedTo: {
      name: "Delhi Jal Board",
      type: "municipal",
      id: "MUN002"
    },
    images: ["/api/placeholder/400/300"],
    upvotes: 18,
    comments: [
      {
        id: "C003",
        author: "DJB Officer",
        message: "Pipeline repaired successfully. Issue resolved.",
        timestamp: "2024-01-13T14:20:00Z",
        type: "admin"
      }
    ],
    createdAt: "2024-01-12T11:30:00Z",
    updatedAt: "2024-01-13T14:20:00Z",
    aiSeverity: "medium",
    estimatedResolution: "Resolved"
  },
  {
    id: "SHR004",
    title: "Overflowing Garbage Bin | भरा हुआ कूड़ादान",
    description: "Community garbage bin overflowing for days, creating unhygienic conditions.",
    category: "waste",
    priority: "medium",
    status: "pending",
    location: {
      address: "Market Area, Lajpat Nagar, New Delhi",
      coordinates: { lat: 28.5244, lng: 77.2315 }
    },
    reportedBy: {
      name: "Sunita Devi",
      phone: "+91 65432 10987",
      id: "USR004"
    },
    images: ["/api/placeholder/400/300"],
    upvotes: 31,
    comments: [],
    createdAt: "2024-01-16T07:45:00Z",
    updatedAt: "2024-01-16T07:45:00Z",
    aiSeverity: "medium",
    estimatedResolution: "24-48 hours"
  },
  {
    id: "SHR005",
    title: "Stray Dogs Issue | आवारा कुत्तों की समस्या",
    description: "Pack of stray dogs creating safety concerns for children and elderly in the area.",
    category: "health",
    priority: "high",
    status: "in-progress",
    location: {
      address: "Green Park Extension, New Delhi",
      coordinates: { lat: 28.5598, lng: 77.2073 }
    },
    reportedBy: {
      name: "Rajesh Gupta",
      phone: "+91 54321 09876",
      id: "USR005"
    },
    assignedTo: {
      name: "Animal Welfare NGO Delhi",
      type: "ngo",
      id: "NGO002"
    },
    images: ["/api/placeholder/400/300"],
    upvotes: 67,
    comments: [
      {
        id: "C004",
        author: "NGO Volunteer",
        message: "Team dispatched for sterilization and vaccination. Will be completed in 2 days.",
        timestamp: "2024-01-15T16:00:00Z",
        type: "ngo"
      }
    ],
    createdAt: "2024-01-14T13:20:00Z",
    updatedAt: "2024-01-15T16:00:00Z",
    aiSeverity: "high",
    estimatedResolution: "48-72 hours"
  }
];

// Mock Workers Data
export const mockWorkers: Worker[] = [
  {
    id: "MUN001",
    name: "Delhi Municipal Corporation - Zone 1",
    type: "municipal",
    contact: "+91 11 2345 6789",
    location: { lat: 28.5355, lng: 77.3910 },
    assignedIssues: 15,
    completedIssues: 142,
    rating: 4.2,
    specialization: ["roads", "electricity", "water"]
  },
  {
    id: "MUN002", 
    name: "Delhi Jal Board",
    type: "municipal",
    contact: "+91 11 3456 7890",
    location: { lat: 28.5921, lng: 77.0460 },
    assignedIssues: 8,
    completedIssues: 89,
    rating: 4.0,
    specialization: ["water"]
  },
  {
    id: "NGO001",
    name: "Road Safety NGO",
    type: "ngo",
    contact: "+91 98765 12345",
    location: { lat: 28.5672, lng: 77.1567 },
    assignedIssues: 5,
    completedIssues: 34,
    rating: 4.7,
    specialization: ["roads", "other"]
  },
  {
    id: "NGO002",
    name: "Animal Welfare NGO Delhi",
    type: "ngo", 
    contact: "+91 87654 23456",
    location: { lat: 28.5598, lng: 77.2073 },
    assignedIssues: 12,
    completedIssues: 78,
    rating: 4.5,
    specialization: ["health", "other"]
  }
];

// Mock Analytics Data
export const mockAnalytics = {
  totalIssues: 1247,
  resolvedIssues: 1089,
  pendingIssues: 158,
  averageResolutionTime: "48 hours",
  citizenSatisfaction: 87,
  topCategories: [
    { category: "roads", count: 456, percentage: 36.6 },
    { category: "water", count: 289, percentage: 23.2 },
    { category: "waste", count: 234, percentage: 18.8 },
    { category: "electricity", count: 156, percentage: 12.5 },
    { category: "health", count: 112, percentage: 9.0 }
  ],
  monthlyTrends: [
    { month: "Jan", issues: 98, resolved: 87 },
    { month: "Feb", issues: 112, resolved: 98 },
    { month: "Mar", issues: 134, resolved: 121 },
    { month: "Apr", issues: 145, resolved: 132 },
    { month: "May", issues: 167, resolved: 156 },
    { month: "Jun", issues: 189, resolved: 178 }
  ]
};

// AI Chatbot responses for mock conversation
export const aiChatbotResponses = {
  greeting: "Namaste! मैं SheharSaaf AI Assistant हूं। आपकी क्या समस्या है? How can I help you report a civic issue today?",
  
  categoryQuestions: {
    roads: "Can you describe the road issue? Is it a pothole, broken road, or traffic signal problem?",
    water: "What type of water issue are you facing? Is it leakage, shortage, or quality problem?",
    waste: "What waste management issue do you see? Overflowing bins, illegal dumping, or collection delay?",
    electricity: "What's the electrical issue? Street light, power outage, or damaged cables?",
    health: "What health-related civic issue needs attention? Stray animals, sanitation, or public health hazard?",
    other: "Please describe the issue in detail so I can understand how to help you."
  },
  
  locationPrompt: "Great! Can you share the exact location or address where this issue is happening?",
  
  urgencyPrompt: "How urgent is this issue? Is it causing immediate danger or inconvenience?",
  
  photoPrompt: "Would you like to upload a photo of the issue? This helps authorities understand the problem better.",
  
  confirmationMessage: "Thank you! Your report has been submitted successfully. Your issue ID is {issueId}. You'll receive updates on your phone. The expected resolution time is {estimatedTime}.",
  
  statusUpdates: [
    "Your issue has been acknowledged by authorities.",
    "A team has been assigned to your issue.",
    "Work has started on resolving your issue.", 
    "Your issue has been resolved. Please verify and provide feedback."
  ]
};

// Mock Citizens Data
export const mockCitizens = [
  {
    id: "USR001",
    name: "Rahul Sharma",
    phone: "+91 98765 43210",
    email: "rahul.sharma@email.com",
    address: "MG Road, Sector 14, New Delhi",
    reportsSubmitted: 12,
    reportsResolved: 9,
    communityScore: 850,
    badges: ["Active Reporter", "Community Helper"],
    joinedDate: "2023-08-15"
  },
  {
    id: "USR002", 
    name: "Priya Singh",
    phone: "+91 87654 32109",
    email: "priya.singh@email.com",
    address: "Vasant Vihar, New Delhi",
    reportsSubmitted: 8,
    reportsResolved: 7,
    communityScore: 650,
    badges: ["Verified Citizen"],
    joinedDate: "2023-09-22"
  }
];