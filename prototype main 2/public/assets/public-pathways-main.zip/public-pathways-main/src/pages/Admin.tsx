import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BarChart3, 
  Users, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Settings,
  TrendingUp,
  MapPin,
  Calendar
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Admin = () => {
  const { toast } = useToast();

  const handleAssignIssue = (issueId: string) => {
    toast({
      title: "Issue Assigned",
      description: `Issue #${issueId} has been assigned to maintenance team.`,
    });
  };

  const handleUpdateStatus = (issueId: string, status: string) => {
    toast({
      title: "Status Updated",
      description: `Issue #${issueId} status changed to ${status}.`,
    });
  };

  const mockIssues = [
    {
      id: "001",
      title: "Broken Street Light on Main Street",
      status: "pending",
      priority: "medium",
      location: "Main Street & 5th Ave",
      date: "2024-01-15",
      reporter: "John Smith",
      assignee: null,
    },
    {
      id: "002",
      title: "Pothole Near School Zone",
      status: "in-progress",
      priority: "high",
      location: "School Rd",
      date: "2024-01-10",
      reporter: "Jane Doe",
      assignee: "Mike Johnson",
    },
    {
      id: "003",
      title: "Graffiti on Community Center",
      status: "resolved",
      priority: "low",
      location: "Community Center",
      date: "2024-01-05",
      reporter: "Bob Wilson",
      assignee: "Sarah Lee",
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-warning text-warning-foreground";
      case "in-progress":
        return "bg-primary text-primary-foreground";
      case "resolved":
        return "bg-success text-success-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-destructive text-destructive-foreground";
      case "medium":
        return "bg-accent text-accent-foreground";
      case "low":
        return "bg-secondary text-secondary-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-muted-foreground mb-6">
            Manage community issues and monitor system performance
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid md:grid-cols-5 gap-6 mb-8">
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-primary mb-1">156</div>
              <div className="text-sm text-muted-foreground flex items-center justify-center">
                <AlertTriangle className="w-4 h-4 mr-1" />
                Total Issues
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-warning mb-1">42</div>
              <div className="text-sm text-muted-foreground flex items-center justify-center">
                <Clock className="w-4 h-4 mr-1" />
                Pending
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-accent mb-1">67</div>
              <div className="text-sm text-muted-foreground flex items-center justify-center">
                <Settings className="w-4 h-4 mr-1" />
                In Progress
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-success mb-1">47</div>
              <div className="text-sm text-muted-foreground flex items-center justify-center">
                <CheckCircle className="w-4 h-4 mr-1" />
                Resolved
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-secondary mb-1">1,234</div>
              <div className="text-sm text-muted-foreground flex items-center justify-center">
                <Users className="w-4 h-4 mr-1" />
                Citizens
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="issues" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="issues">Issue Management</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="settings">System Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="issues" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Recent Issues</h2>
              <Button variant="outline" size="sm">
                <BarChart3 className="w-4 h-4 mr-2" />
                Export Report
              </Button>
            </div>

            <div className="space-y-4">
              {mockIssues.map((issue) => (
                <Card key={issue.id} className="bg-gradient-card shadow-soft">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <CardTitle className="text-lg">{issue.title}</CardTitle>
                          <Badge className={getPriorityColor(issue.priority)}>
                            {issue.priority}
                          </Badge>
                          <Badge className={getStatusColor(issue.status)}>
                            {issue.status.replace('-', ' ')}
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <div className="flex items-center space-x-1">
                            <MapPin className="w-4 h-4" />
                            <span>{issue.location}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Calendar className="w-4 h-4" />
                            <span>{issue.date}</span>
                          </div>
                          <span>Reporter: {issue.reporter}</span>
                          {issue.assignee && <span>Assignee: {issue.assignee}</span>}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center space-x-2">
                      {!issue.assignee && issue.status === "pending" && (
                        <Button
                          size="sm"
                          onClick={() => handleAssignIssue(issue.id)}
                          className="transition-smooth"
                        >
                          Assign Team
                        </Button>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleUpdateStatus(issue.id, "in-progress")}
                        className="transition-smooth"
                      >
                        Update Status
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="transition-smooth"
                      >
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-gradient-card shadow-soft">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="w-5 h-5" />
                    <span>Issue Trends</span>
                  </CardTitle>
                  <CardDescription>
                    Monthly issue reports and resolution rates
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8 text-muted-foreground">
                    Interactive chart would be displayed here
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-card shadow-soft">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="w-5 h-5" />
                    <span>Response Times</span>
                  </CardTitle>
                  <CardDescription>
                    Average response and resolution times
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Avg Response Time</span>
                      <span className="font-semibold">2.4 hours</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Avg Resolution Time</span>
                      <span className="font-semibold">18.6 hours</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Success Rate</span>
                      <span className="font-semibold">94.2%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card className="bg-gradient-card shadow-soft">
              <CardHeader>
                <CardTitle>System Configuration</CardTitle>
                <CardDescription>
                  Manage system settings and user permissions
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="mr-4">User Management</Button>
                <Button variant="outline" className="mr-4">Notification Settings</Button>
                <Button variant="outline">System Backup</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Admin;