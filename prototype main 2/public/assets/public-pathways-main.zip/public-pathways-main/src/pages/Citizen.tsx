import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, MapPin, AlertCircle, CheckCircle, Clock, MessageSquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Citizen = () => {
  const { toast } = useToast();

  const handleReportIssue = () => {
    toast({
      title: "Report Issue",
      description: "Issue reporting form would open here.",
    });
  };

  const handleViewIssue = (issueId: string) => {
    toast({
      title: "View Issue",
      description: `Viewing details for issue #${issueId}`,
    });
  };

  const mockIssues = [
    {
      id: "001",
      title: "Broken Street Light on Main Street",
      status: "pending",
      priority: "medium",
      location: "Main Street & 5th Ave",
      date: "2024-01-15",
      comments: 3,
    },
    {
      id: "002",
      title: "Pothole Near School Zone",
      status: "in-progress",
      priority: "high",
      location: "School Rd",
      date: "2024-01-10",
      comments: 8,
    },
    {
      id: "003",
      title: "Graffiti on Community Center",
      status: "resolved",
      priority: "low",
      location: "Community Center",
      date: "2024-01-05",
      comments: 2,
    },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="w-4 h-4" />;
      case "in-progress":
        return <AlertCircle className="w-4 h-4" />;
      case "resolved":
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-warning text-warning-foreground";
      case "in-progress":
        return "bg-primary text-primary-foreground";
      case "resolved":
        return "bg-success text-success-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-destructive text-destructive-foreground";
      case "medium":
        return "bg-accent text-accent-foreground";
      case "low":
        return "bg-secondary text-secondary-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Citizen Dashboard</h1>
          <p className="text-muted-foreground mb-6">
            Report community issues and track their progress
          </p>
          
          <Button
            onClick={handleReportIssue}
            className="bg-gradient-hero hover:opacity-90 transition-smooth shadow-medium"
            size="lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Report New Issue
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-primary mb-1">12</div>
              <div className="text-sm text-muted-foreground">Total Reports</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-warning mb-1">3</div>
              <div className="text-sm text-muted-foreground">Pending</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-accent mb-1">4</div>
              <div className="text-sm text-muted-foreground">In Progress</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-success mb-1">5</div>
              <div className="text-sm text-muted-foreground">Resolved</div>
            </CardContent>
          </Card>
        </div>

        {/* Issues List */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold mb-4">Your Recent Reports</h2>
          
          {mockIssues.map((issue) => (
            <Card key={issue.id} className="bg-gradient-card shadow-soft hover:shadow-medium transition-smooth">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <CardTitle className="text-lg">{issue.title}</CardTitle>
                      <Badge className={getPriorityColor(issue.priority)}>
                        {issue.priority}
                      </Badge>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                      <div className="flex items-center space-x-1">
                        <MapPin className="w-4 h-4" />
                        <span>{issue.location}</span>
                      </div>
                      <span>#{issue.id}</span>
                      <span>{issue.date}</span>
                    </div>
                  </div>
                  <Badge className={getStatusColor(issue.status)}>
                    {getStatusIcon(issue.status)}
                    <span className="ml-1 capitalize">{issue.status.replace('-', ' ')}</span>
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                    <MessageSquare className="w-4 h-4" />
                    <span>{issue.comments} comments</span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleViewIssue(issue.id)}
                    className="transition-smooth"
                  >
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Citizen;