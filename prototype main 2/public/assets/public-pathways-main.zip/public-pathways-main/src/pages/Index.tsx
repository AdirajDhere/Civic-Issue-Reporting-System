import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { Users, Shield, Heart, ArrowRight, CheckCircle, TrendingUp, Globe, Star, MapPin, MessageCircle } from "lucide-react";
import heroImage from "@/assets/hero-community.jpg";

const Index = () => {
  const features = [
    {
      icon: MessageCircle,
      title: "AI Chatbot | एआई चैटबॉट",
      description: "Smart AI assistant to report issues quickly and track resolution status in Hindi and English.",
    },
    {
      icon: Shield,
      title: "Municipal Dashboard | नगरीय डैशबोर्ड",
      description: "Complete admin tools for efficient issue management and civic coordination.",
    },
    {
      icon: Heart,
      title: "NGO Portal | एनजीओ पोर्टल",
      description: "Coordinate community initiatives and manage volunteer programs effectively.",
    },
  ];

  const stats = [
    { label: "Active Citizens | सक्रिय नागरिक", value: "2,500+", icon: Users },
    { label: "Issues Resolved | समस्याएं हल", value: "5,400+", icon: CheckCircle },
    { label: "Cities Connected | जुड़े शहर", value: "12+", icon: Globe },
    { label: "Community Impact | सामुदायिक प्रभाव", value: "94%", icon: TrendingUp },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section 
        className="relative py-20 px-4 bg-gradient-hero text-white overflow-hidden"
        style={{
          backgroundImage: `linear-gradient(135deg, rgba(255, 153, 51, 0.95), rgba(33, 150, 243, 0.95)), url(${heroImage})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="container mx-auto text-center relative z-10">
          <div className="flex items-center justify-center mb-6">
            <Star className="w-12 h-12 text-yellow-300 mr-3" />
            <h1 className="text-5xl md:text-6xl font-bold leading-tight">
              SheharSaaf
            </h1>
          </div>
          <p className="text-xl md:text-2xl mb-2 max-w-3xl mx-auto opacity-95 font-medium">
            शहर साफ़ | AI-Powered Civic Issue Reporting
          </p>
          <p className="text-lg mb-8 max-w-2xl mx-auto opacity-90">
            Connecting Citizens, Government & NGOs for a Cleaner, Better India
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button asChild size="lg" className="bg-white text-primary hover:bg-gray-100 shadow-strong font-semibold">
              <Link to="/citizen" className="flex items-center">
                <Users className="w-5 h-5 mr-2" />
                Start as Citizen | नागरिक के रूप में
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="border-white/30 bg-white/10 text-white hover:bg-white/20 font-semibold">
              <Link to="/admin" className="flex items-center">
                <Shield className="w-5 h-5 mr-2" />
                Admin Portal | व्यवस्थापक
              </Link>
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
            {stats.map((stat, index) => (
              <div key={index} className="text-center bg-white/10 backdrop-blur-sm rounded-lg p-4 transition-smooth hover:bg-white/20">
                <div className="flex justify-center mb-2">
                  <stat.icon className="w-8 h-8 text-yellow-300" />
                </div>
                <div className="text-2xl font-bold mb-1">{stat.value}</div>
                <div className="text-xs opacity-90 leading-tight">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-primary">
              Every Voice Matters | हर आवाज़ मायने रखती है
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Choose your role and contribute to making our cities cleaner and better
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {features.map((feature, index) => (
              <Card key={index} className="bg-gradient-card shadow-soft hover:shadow-medium transition-smooth text-center p-8 border-2 hover:border-primary/20">
                <CardHeader className="pb-4">
                  <div className="w-16 h-16 bg-gradient-saffron rounded-full flex items-center justify-center mx-auto mb-4 shadow-glow">
                    <feature.icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-xl mb-2 text-primary">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base leading-relaxed">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Call to Action Cards */}
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="bg-gradient-card shadow-medium hover:shadow-strong transition-smooth border-2 hover:border-primary/30">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mx-auto mb-3 shadow-glow">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-primary">Citizen Portal | नागरिक पोर्टल</CardTitle>
                <CardDescription>
                  Report issues with AI chatbot, track progress, and connect with your community
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <Button asChild className="w-full transition-smooth bg-gradient-saffron border-0 font-semibold">
                  <Link to="/citizen">
                    Access Dashboard | डैशबोर्ड खोलें
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card shadow-medium hover:shadow-strong transition-smooth border-2 hover:border-secondary/30">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center mx-auto mb-3 shadow-glow">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-secondary">Admin Portal | प्रशासन पोर्टल</CardTitle>
                <CardDescription>
                  Municipal dashboard with maps, analytics, and complete issue management
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <Button asChild variant="secondary" className="w-full transition-smooth font-semibold">
                  <Link to="/admin">
                    Access Admin Panel | व्यवस्थापक पैनल
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card shadow-medium hover:shadow-strong transition-smooth border-2 hover:border-accent/30">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-accent rounded-lg flex items-center justify-center mx-auto mb-3 shadow-glow">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-accent">NGO Portal | एनजीओ पोर्टल</CardTitle>
                <CardDescription>
                  Coordinate community programs, manage volunteers, and track social impact
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <Button asChild variant="outline" className="w-full transition-smooth border-accent text-accent hover:bg-accent hover:text-accent-foreground font-semibold">
                  <Link to="/ngo">
                    Access NGO Dashboard | एनजीओ डैशबोर्ड
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Government Partnership Badge */}
          <div className="text-center mt-16">
            <div className="inline-flex items-center bg-gradient-tricolor rounded-full px-6 py-3 shadow-medium">
              <MapPin className="w-5 h-5 text-white mr-2" />
              <span className="text-white font-semibold">Supporting Swachh Bharat Mission | स्वच्छ भारत मिशन</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
