import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Heart, 
  Users, 
  Target, 
  Calendar,
  MapPin,
  Handshake,
  TrendingUp,
  Plus,
  FileText,
  Award
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const NGO = () => {
  const { toast } = useToast();

  const handleCreateCampaign = () => {
    toast({
      title: "Create Campaign",
      description: "Campaign creation form would open here.",
    });
  };

  const handleJoinProject = (projectId: string) => {
    toast({
      title: "Join Project",
      description: `Application sent for project #${projectId}`,
    });
  };

  const mockProjects = [
    {
      id: "001",
      title: "Clean Streets Initiative",
      category: "Environment",
      status: "active",
      location: "Downtown Area",
      volunteers: 45,
      target: 100,
      deadline: "2024-03-15",
      description: "Community-wide effort to maintain clean streets and public spaces.",
    },
    {
      id: "002",
      title: "Youth Education Program",
      category: "Education",
      status: "planning",
      location: "Community Centers",
      volunteers: 12,
      target: 25,
      deadline: "2024-02-28",
      description: "After-school tutoring and mentorship programs for local students.",
    },
    {
      id: "003",
      title: "Senior Assistance Network",
      category: "Healthcare",
      status: "active",
      location: "Citywide",
      volunteers: 67,
      target: 80,
      deadline: "2024-04-30",
      description: "Support services and regular check-ins for elderly community members.",
    },
  ];

  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case "environment":
        return "bg-success text-success-foreground";
      case "education":
        return "bg-primary text-primary-foreground";
      case "healthcare":
        return "bg-accent text-accent-foreground";
      default:
        return "bg-secondary text-secondary-foreground";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-success text-success-foreground";
      case "planning":
        return "bg-warning text-warning-foreground";
      case "completed":
        return "bg-muted text-muted-foreground";
      default:
        return "bg-secondary text-secondary-foreground";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">NGO Dashboard</h1>
          <p className="text-muted-foreground mb-6">
            Coordinate community initiatives and manage volunteer programs
          </p>
          
          <Button
            onClick={handleCreateCampaign}
            className="bg-gradient-hero hover:opacity-90 transition-smooth shadow-medium"
            size="lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Create Campaign
          </Button>
        </div>

        {/* Impact Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-primary mb-1">124</div>
              <div className="text-sm text-muted-foreground flex items-center justify-center">
                <Users className="w-4 h-4 mr-1" />
                Active Volunteers
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-success mb-1">18</div>
              <div className="text-sm text-muted-foreground flex items-center justify-center">
                <Target className="w-4 h-4 mr-1" />
                Active Projects
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-accent mb-1">2,347</div>
              <div className="text-sm text-muted-foreground flex items-center justify-center">
                <Heart className="w-4 h-4 mr-1" />
                People Helped
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-secondary mb-1">$45K</div>
              <div className="text-sm text-muted-foreground flex items-center justify-center">
                <Award className="w-4 h-4 mr-1" />
                Funds Raised
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="projects" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="volunteers">Volunteers</TabsTrigger>
            <TabsTrigger value="impact">Impact Report</TabsTrigger>
            <TabsTrigger value="partnerships">Partnerships</TabsTrigger>
          </TabsList>

          <TabsContent value="projects" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Community Projects</h2>
              <Button variant="outline" size="sm">
                <FileText className="w-4 h-4 mr-2" />
                Project Report
              </Button>
            </div>

            <div className="space-y-4">
              {mockProjects.map((project) => (
                <Card key={project.id} className="bg-gradient-card shadow-soft hover:shadow-medium transition-smooth">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <CardTitle className="text-lg">{project.title}</CardTitle>
                          <Badge className={getCategoryColor(project.category)}>
                            {project.category}
                          </Badge>
                          <Badge className={getStatusColor(project.status)}>
                            {project.status}
                          </Badge>
                        </div>
                        <CardDescription>{project.description}</CardDescription>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <div className="flex items-center space-x-1">
                            <MapPin className="w-4 h-4" />
                            <span>{project.location}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Calendar className="w-4 h-4" />
                            <span>Due: {project.deadline}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="text-sm">
                          <span className="font-medium">{project.volunteers}</span>
                          <span className="text-muted-foreground">/{project.target} volunteers</span>
                        </div>
                        <div className="w-24 bg-muted rounded-full h-2">
                          <div 
                            className="bg-primary h-2 rounded-full transition-smooth"
                            style={{ width: `${(project.volunteers / project.target) * 100}%` }}
                          />
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleJoinProject(project.id)}
                          className="transition-smooth"
                        >
                          <Handshake className="w-4 h-4 mr-1" />
                          Join Project
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="transition-smooth"
                        >
                          View Details
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="volunteers" className="space-y-6">
            <Card className="bg-gradient-card shadow-soft">
              <CardHeader>
                <CardTitle>Volunteer Management</CardTitle>
                <CardDescription>
                  Manage your volunteer base and recruitment efforts
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>New Volunteers (This Month)</span>
                      <span className="font-semibold">23</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Active Volunteers</span>
                      <span className="font-semibold">124</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Retention Rate</span>
                      <span className="font-semibold">87%</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Button className="w-full">Recruit Volunteers</Button>
                    <Button variant="outline" className="w-full">Training Schedule</Button>
                    <Button variant="outline" className="w-full">Volunteer Database</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="impact" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-gradient-card shadow-soft">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="w-5 h-5" />
                    <span>Community Impact</span>
                  </CardTitle>
                  <CardDescription>
                    Track your organization's positive impact on the community
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Lives Impacted</span>
                      <span className="font-semibold text-primary">2,347</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Volunteer Hours</span>
                      <span className="font-semibold text-success">1,856</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Community Satisfaction</span>
                      <span className="font-semibold text-accent">96%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-card shadow-soft">
                <CardHeader>
                  <CardTitle>Monthly Progress</CardTitle>
                  <CardDescription>
                    Your organization's growth and impact metrics
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8 text-muted-foreground">
                    Impact charts and metrics would be displayed here
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="partnerships" className="space-y-6">
            <Card className="bg-gradient-card shadow-soft">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Handshake className="w-5 h-5" />
                  <span>Partner Organizations</span>
                </CardTitle>
                <CardDescription>
                  Collaborate with other NGOs and community organizations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-3 gap-4">
                  <Button className="h-20 flex-col space-y-2">
                    <Heart className="w-6 h-6" />
                    <span>Health Partners</span>
                  </Button>
                  <Button variant="outline" className="h-20 flex-col space-y-2">
                    <Users className="w-6 h-6" />
                    <span>Education Alliance</span>
                  </Button>
                  <Button variant="outline" className="h-20 flex-col space-y-2">
                    <Target className="w-6 h-6" />
                    <span>Environmental Groups</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default NGO;