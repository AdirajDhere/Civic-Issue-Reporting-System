import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { MessageCircle, Send, Mic, Star } from "lucide-react";
import { Link } from "react-router-dom";

const CitizenChatbot = () => {
  const [messages, setMessages] = useState([
    { id: 1, type: 'bot', text: 'Namaste! मैं SheharSaaf AI Assistant हूं। आपकी क्या समस्या है? How can I help you report a civic issue today?' }
  ]);
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (input.trim()) {
      setMessages([...messages, 
        { id: messages.length + 1, type: 'user', text: input },
        { id: messages.length + 2, type: 'bot', text: 'I understand your concern. Can you tell me the exact location where this issue is happening?' }
      ]);
      setInput('');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Star className="w-6 h-6 text-primary mr-2" />
            <h1 className="text-2xl font-bold text-primary">AI Assistant | एआई सहायक</h1>
          </div>
          <Link to="/citizen/home">
            <Button variant="outline">← Back</Button>
          </Link>
        </div>

        <Card className="h-[600px] flex flex-col">
          <CardHeader>
            <CardTitle className="flex items-center">
              <MessageCircle className="w-5 h-5 mr-2" />
              Chat with SheharSaaf AI
            </CardTitle>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col">
            <div className="flex-1 overflow-y-auto space-y-4 mb-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] p-3 rounded-lg ${
                    message.type === 'user' 
                      ? 'bg-primary text-white' 
                      : 'bg-muted'
                  }`}>
                    {message.text}
                  </div>
                </div>
              ))}
            </div>
            <div className="flex space-x-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your message... | अपना संदेश टाइप करें..."
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              />
              <Button onClick={handleSend}>
                <Send className="w-4 h-4" />
              </Button>
              <Button variant="outline">
                <Mic className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CitizenChatbot;