import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { 
  MessageCircle, 
  Plus, 
  Eye, 
  MapPin, 
  User, 
  Award,
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertTriangle
} from "lucide-react";

const CitizenHome = () => {
  const quickActions = [
    {
      icon: MessageCircle,
      title: "AI Assistant | एआई सहायक",
      description: "Chat with our AI to report issues quickly",
      link: "/citizen/chatbot",
      color: "bg-gradient-saffron",
    },
    {
      icon: Plus,
      title: "Report Issue | समस्या रिपोर्ट करें",
      description: "Submit new civic issue report",
      link: "/citizen/report",
      color: "bg-primary",
    },
    {
      icon: Eye,
      title: "My Reports | मेरी रिपोर्ट्स",
      description: "Track your submitted reports",
      link: "/citizen/reports",
      color: "bg-secondary",
    },
    {
      icon: MapPin,
      title: "Nearby Issues | पास की समस्याएं",
      description: "See issues in your area",
      link: "/citizen/nearby",
      color: "bg-accent",
    },
  ];

  const userStats = {
    reportsSubmitted: 12,
    reportsResolved: 9,
    communityScore: 850,
    level: "Community Helper"
  };

  const recentActivity = [
    {
      id: "SHR001",
      title: "Street Light Repair",
      status: "in-progress",
      timestamp: "2 hours ago",
      location: "MG Road"
    },
    {
      id: "SHR002", 
      title: "Pothole Report",
      status: "acknowledged",
      timestamp: "1 day ago",
      location: "School Road"
    },
    {
      id: "SHR003",
      title: "Water Leakage",
      status: "resolved", 
      timestamp: "3 days ago",
      location: "Dwarka Block C"
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "resolved":
        return <CheckCircle2 className="w-4 h-4 text-success" />;
      case "in-progress":
        return <Clock className="w-4 h-4 text-accent" />;  
      case "acknowledged":
        return <AlertTriangle className="w-4 h-4 text-warning" />;
      default:
        return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "resolved":
        return "bg-success text-success-foreground";
      case "in-progress":
        return "bg-accent text-accent-foreground";
      case "acknowledged":
        return "bg-warning text-warning-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-6">
        {/* Welcome Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-primary">Welcome, Rahul! | आपका स्वागत है!</h1>
              <p className="text-muted-foreground">Ready to make your city better today?</p>
            </div>
            <Link to="/citizen/profile">
              <Button variant="outline" className="flex items-center">
                <User className="w-4 h-4 mr-2" />
                Profile
              </Button>
            </Link>
          </div>

          {/* User Level Badge */}
          <div className="flex items-center space-x-2">
            <Badge className="bg-gradient-saffron text-white font-semibold px-3 py-1">
              <Award className="w-4 h-4 mr-1" />
              {userStats.level}
            </Badge>
            <span className="text-sm text-muted-foreground">
              Score: {userStats.communityScore} points
            </span>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary mb-1">{userStats.reportsSubmitted}</div>
              <div className="text-xs text-muted-foreground">Reports Submitted</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-success mb-1">{userStats.reportsResolved}</div>
              <div className="text-xs text-muted-foreground">Issues Resolved</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-accent mb-1">3</div>
              <div className="text-xs text-muted-foreground">In Progress</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card shadow-soft">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-warning mb-1">75%</div>
              <div className="text-xs text-muted-foreground">Success Rate</div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4 text-primary">Quick Actions | त्वरित कार्य</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action, index) => (
              <Link to={action.link} key={index}>
                <Card className="bg-gradient-card shadow-soft hover:shadow-medium transition-smooth cursor-pointer border-2 hover:border-primary/20">
                  <CardContent className="p-6 text-center">
                    <div className={`w-12 h-12 ${action.color} rounded-lg flex items-center justify-center mx-auto mb-3 shadow-glow`}>
                      <action.icon className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-base mb-2">{action.title}</CardTitle>
                    <CardDescription className="text-sm">{action.description}</CardDescription>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-primary">Recent Activity | हाल की गतिविधि</h2>
            <Link to="/citizen/reports">
              <Button variant="outline" size="sm">
                View All | सभी देखें
              </Button>
            </Link>
          </div>
          
          <div className="space-y-3">
            {recentActivity.map((activity) => (
              <Card key={activity.id} className="bg-gradient-card shadow-soft hover:shadow-medium transition-smooth">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(activity.status)}
                      <div>
                        <div className="font-medium text-sm">{activity.title}</div>
                        <div className="text-xs text-muted-foreground flex items-center">
                          <MapPin className="w-3 h-3 mr-1" />
                          {activity.location} • {activity.timestamp}
                        </div>
                      </div>
                    </div>
                    <Badge className={`${getStatusColor(activity.status)} text-xs`}>
                      {activity.status.replace('-', ' ')}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Community Impact */}
        <Card className="bg-gradient-card shadow-medium">
          <CardHeader>
            <CardTitle className="flex items-center text-primary">
              <TrendingUp className="w-5 h-5 mr-2" />
              Community Impact | सामुदायिक प्रभाव
            </CardTitle>
            <CardDescription>
              Your contribution to making the city better
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">2,347</div>
                <div className="text-sm text-muted-foreground">Citizens Helped</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-success mb-2">48hrs</div>
                <div className="text-sm text-muted-foreground">Avg Resolution Time</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent mb-2">94%</div>
                <div className="text-sm text-muted-foreground">Community Satisfaction</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CitizenHome;