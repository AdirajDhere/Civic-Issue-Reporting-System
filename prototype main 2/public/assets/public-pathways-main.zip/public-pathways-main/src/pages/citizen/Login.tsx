import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link, useNavigate } from "react-router-dom";
import { Star, Phone, Lock, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const CitizenLogin = () => {
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [showOTP, setShowOTP] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSendOTP = () => {
    if (phone.length === 10) {
      setShowOTP(true);
      toast({
        title: "OTP Sent | ओटीपी भेजा गया",
        description: `Verification code sent to +91 ${phone}`,
      });
    } else {
      toast({
        title: "Invalid Phone Number",
        description: "Please enter a valid 10-digit phone number",
        variant: "destructive",
      });
    }
  };

  const handleLogin = () => {
    if (otp === "1234") {
      toast({
        title: "Login Successful | लॉगिन सफल",
        description: "Welcome to SheharSaaf! आपका स्वागत है!",
      });
      navigate("/citizen/home");
    } else {
      toast({
        title: "Invalid OTP",
        description: "Please enter the correct verification code",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Star className="w-10 h-10 text-yellow-300 mr-2" />
            <h1 className="text-3xl font-bold text-white">SheharSaaf</h1>
          </div>
          <p className="text-white/90">Citizen Login | नागरिक लॉगिन</p>
        </div>

        <Card className="bg-white/95 backdrop-blur-sm shadow-strong">
          <CardHeader className="text-center">
            <CardTitle className="text-primary">Welcome Back | वापस आपका स्वागत है</CardTitle>
            <CardDescription>
              Login to report issues and track progress
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="phone" className="text-sm font-medium">
                Phone Number | फ़ोन नंबर
              </Label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="phone"
                  type="tel"
                  placeholder="Enter 10-digit phone number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                  className="pl-10"
                  disabled={showOTP}
                />
              </div>
            </div>

            {!showOTP ? (
              <Button 
                onClick={handleSendOTP}
                className="w-full bg-gradient-saffron font-semibold"
              >
                Send OTP | ओटीपी भेजें
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <>
                <div className="space-y-2">
                  <Label htmlFor="otp" className="text-sm font-medium">
                    Enter OTP | ओटीपी दर्ज करें
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="otp"
                      type="text"
                      placeholder="Enter 4-digit OTP"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 4))}
                      className="pl-10"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Demo OTP: 1234 for testing
                  </p>
                </div>

                <Button 
                  onClick={handleLogin}
                  className="w-full bg-gradient-saffron font-semibold"
                >
                  Verify & Login | सत्यापित करें और लॉगिन करें
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>

                <Button 
                  variant="ghost" 
                  onClick={() => setShowOTP(false)}
                  className="w-full text-sm"
                >
                  Change Phone Number | फ़ोन नंबर बदलें
                </Button>
              </>
            )}

            <div className="text-center">
              <p className="text-sm text-muted-foreground">
                Don't have an account? | खाता नहीं है?{" "}
                <Link to="/citizen/signup" className="text-primary hover:underline font-medium">
                  Sign up here | यहाँ साइन अप करें
                </Link>
              </p>
            </div>

            <div className="text-center pt-4 border-t">
              <Link to="/" className="text-sm text-muted-foreground hover:text-primary">
                ← Back to Home | होम पर वापस जाएं  
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CitizenLogin;