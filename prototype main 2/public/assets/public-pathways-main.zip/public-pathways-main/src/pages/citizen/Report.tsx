import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { Plus, Camera, MapPin } from "lucide-react";

const CitizenReport = () => {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-primary">Report Issue | समस्या रिपोर्ट करें</h1>
          <Link to="/citizen/home">
            <Button variant="outline">← Back</Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Plus className="w-5 h-5 mr-2" />
              New Issue Report
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Button className="h-24 flex-col space-y-2">
                <Camera className="w-8 h-8" />
                <span>Upload Photo</span>
              </Button>
              <Button variant="outline" className="h-24 flex-col space-y-2">
                <MapPin className="w-8 h-8" />
                <span>Add Location</span>
              </Button>
            </div>
            <div className="text-center">
              <p className="text-muted-foreground mb-4">Or use our AI Assistant for faster reporting</p>
              <Link to="/citizen/chatbot">
                <Button className="bg-gradient-saffron">
                  Chat with AI Assistant
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CitizenReport;