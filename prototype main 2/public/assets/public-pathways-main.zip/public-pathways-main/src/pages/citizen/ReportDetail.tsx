import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

const CitizenReportDetail = () => {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center mb-6">
          <Link to="/citizen/reports">
            <Button variant="outline" size="sm" className="mr-4">
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-primary">Issue Details | समस्या विवरण</h1>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-start justify-between">
              <CardTitle>Broken Street Light on MG Road</CardTitle>
              <Badge className="bg-accent text-white">in-progress</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Issue details would be displayed here with photos, timeline, and updates.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CitizenReportDetail;