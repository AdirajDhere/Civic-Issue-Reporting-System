import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Eye, MapPin, Clock } from "lucide-react";
import { mockIssues } from "@/data/mockData";

const CitizenReports = () => {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-primary">My Reports | मेरी रिपोर्ट्स</h1>
          <Link to="/citizen/home">
            <Button variant="outline">← Back</Button>
          </Link>
        </div>

        <div className="space-y-4">
          {mockIssues.slice(0, 3).map((issue) => (
            <Card key={issue.id} className="hover:shadow-medium transition-smooth">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{issue.title}</CardTitle>
                    <div className="flex items-center space-x-4 text-sm text-muted-foreground mt-2">
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 mr-1" />
                        {issue.location.address}
                      </div>
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {issue.createdAt}
                      </div>
                    </div>
                  </div>
                  <Badge className={`${
                    issue.status === 'resolved' ? 'bg-success' : 
                    issue.status === 'in-progress' ? 'bg-accent' : 'bg-warning'
                  } text-white`}>
                    {issue.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <p className="text-sm text-muted-foreground">{issue.description.slice(0, 100)}...</p>
                  <Link to={`/citizen/report/${issue.id}`}>
                    <Button variant="outline" size="sm">
                      <Eye className="w-4 h-4 mr-1" />
                      View Details
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CitizenReports;