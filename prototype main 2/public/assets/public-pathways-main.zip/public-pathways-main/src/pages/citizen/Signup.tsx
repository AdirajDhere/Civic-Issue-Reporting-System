import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link, useNavigate } from "react-router-dom";
import { Star, Phone, User, Mail, MapPin, Lock, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const CitizenSignup = () => {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
  });
  const [otp, setOtp] = useState("");
  const [showOTP, setShowOTP] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSendOTP = () => {
    if (formData.name && formData.phone.length === 10 && formData.email && formData.address) {
      setShowOTP(true);
      toast({
        title: "OTP Sent | ओटीपी भेजा गया",
        description: `Verification code sent to +91 ${formData.phone}`,
      });
    } else {
      toast({
        title: "Please Fill All Fields",
        description: "All fields are required to create your account",
        variant: "destructive",
      });
    }
  };

  const handleSignup = () => {
    if (otp === "1234") {
      toast({
        title: "Account Created Successfully! | खाता सफलतापूर्वक बनाया गया!",
        description: "Welcome to SheharSaaf community!",
      });
      navigate("/citizen/home");
    } else {
      toast({
        title: "Invalid OTP",
        description: "Please enter the correct verification code",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Star className="w-10 h-10 text-yellow-300 mr-2" />
            <h1 className="text-3xl font-bold text-white">SheharSaaf</h1>
          </div>
          <p className="text-white/90">Join the Community | समुदाय में शामिल हों</p>
        </div>

        <Card className="bg-white/95 backdrop-blur-sm shadow-strong">
          <CardHeader className="text-center">
            <CardTitle className="text-primary">Create Account | खाता बनाएं</CardTitle>
            <CardDescription>
              Join thousands of citizens making our cities better
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {!showOTP ? (
              <>
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-sm font-medium">
                    Full Name | पूरा नाम
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="name"
                      type="text"
                      placeholder="Enter your full name"
                      value={formData.name}
                      onChange={(e) => handleInputChange("name", e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-sm font-medium">
                    Phone Number | फ़ोन नंबर
                  </Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="Enter 10-digit phone number"
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value.replace(/\D/g, '').slice(0, 10))}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium">
                    Email Address | ईमेल पता
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email address"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address" className="text-sm font-medium">
                    Address | पता
                  </Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="address"
                      type="text"
                      placeholder="Enter your address"
                      value={formData.address}
                      onChange={(e) => handleInputChange("address", e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <Button 
                  onClick={handleSendOTP}
                  className="w-full bg-gradient-saffron font-semibold"
                >
                  Send OTP | ओटीपी भेजें
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </>
            ) : (
              <>
                <div className="text-center mb-4">
                  <p className="text-sm text-muted-foreground">
                    OTP sent to +91 {formData.phone}
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="otp" className="text-sm font-medium">
                    Enter OTP | ओटीपी दर्ज करें
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="otp"
                      type="text"
                      placeholder="Enter 4-digit OTP"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 4))}
                      className="pl-10"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Demo OTP: 1234 for testing
                  </p>
                </div>

                <Button 
                  onClick={handleSignup}
                  className="w-full bg-gradient-saffron font-semibold"
                >
                  Create Account | खाता बनाएं
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>

                <Button 
                  variant="ghost" 
                  onClick={() => setShowOTP(false)}
                  className="w-full text-sm"
                >
                  Change Details | विवरण बदलें
                </Button>
              </>
            )}

            <div className="text-center">
              <p className="text-sm text-muted-foreground">
                Already have an account? | पहले से खाता है?{" "}
                <Link to="/citizen/login" className="text-primary hover:underline font-medium">
                  Login here | यहाँ लॉगिन करें
                </Link>
              </p>
            </div>

            <div className="text-center pt-4 border-t">
              <Link to="/" className="text-sm text-muted-foreground hover:text-primary">
                ← Back to Home | होम पर वापस जाएं  
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CitizenSignup;